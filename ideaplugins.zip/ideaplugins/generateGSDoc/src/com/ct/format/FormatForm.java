package com.ct.format;

import javax.swing.*;

/**
 * Created by chengtongtong on 2016/12/17.
 */
public class FormatForm {

    public JLabel description;
    public JTextArea setFormatTextArea;
    public JTextArea getFormatTextArea;
    public JPanel mainPanel;
    public JPanel setPanel;
    public JPanel getPanel;

    public FormatForm() {

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("FormatForm");
        frame.setContentPane(new FormatForm().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
