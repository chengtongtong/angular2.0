package com.ct.format.setting;

/**
 * Created by chengtongtong on 2016/12/17.
 */
public class StatementGenerator {

    public static String defaultGetFormat = "/**  \n" +
            " * 获取 ${bare_field_name}  \n" +
            " *\n" +
            " * @return ${bare_field_name} ${bare_field_name}  \n" +
            " */";

    public static String defaultSetFormat = "/**  \n" +
            " * 设置 ${bare_field_name} \n" +
            " * \n" +
            " * @param ${bare_field_name} ${bare_field_name}  \n" +
            " */  ";

}
