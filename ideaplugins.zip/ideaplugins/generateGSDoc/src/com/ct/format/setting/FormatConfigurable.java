package com.ct.format.setting;

import com.ct.format.FormatForm;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SearchableConfigurable;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * Created by chengtongtong on 2016/12/17.
 */
public class FormatConfigurable implements SearchableConfigurable {

    private FormatForm formatForm;

    private FormatSetting formatSetting;

    public FormatConfigurable() {
        this.formatSetting = FormatSetting.getInstance();
    }

    @NotNull
    @Override
    public String getId() {
        return "DocFormat";
    }

    @Nls
    @Override
    public String getDisplayName() {
        return this.getId();
    }

    @Nullable
    @Override
    public String getHelpTopic() {
        return this.getId();
    }

    @Nullable
    @Override
    public JComponent createComponent() {
        if (null == this.formatForm) {
            this.formatForm = new FormatForm();
        }
        return this.formatForm.mainPanel;
    }

    @Override
    public boolean isModified() {
        return !this.formatSetting.getGetFormat().equals(StatementGenerator.defaultGetFormat) || !this.formatSetting.getSetFormat().equals(StatementGenerator.defaultSetFormat);
    }

    @Override
    public void apply() throws ConfigurationException {
        this.formatSetting.setGetFormat(this.formatForm.getFormatTextArea.getText());
        this.formatSetting.setSetFormat(this.formatForm.setFormatTextArea.getText());
    }

    @Override
    public void reset() {
        this.formatSetting.setGetFormat(StatementGenerator.defaultGetFormat);
        this.formatSetting.setSetFormat(StatementGenerator.defaultSetFormat);
    }
}
