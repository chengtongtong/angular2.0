package com.ct.format.setting;

import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import org.jdom.Element;
import org.jetbrains.annotations.Nullable;

/**
 * Created by chengtongtong on 2016/12/17.
 */
@State(
        name = "FormatSetting",
        storages = {@Storage(
                id = "other",
                file = "$APP_CONFIG$/format.xml"
        )}
)
public class FormatSetting implements PersistentStateComponent<Element> {

    // private Gson gson = new Gson();

    private String setFormat;

    private String getFormat;

    public FormatSetting() {
        super();
    }

    public static FormatSetting getInstance() {
        return (FormatSetting) ServiceManager.getService(FormatSetting.class);
    }

    @Nullable
    @Override
    public Element getState() {
        Element element = new Element("FormatSetting");
        element.setAttribute("setFormat", String.valueOf(StatementGenerator.defaultSetFormat));
        element.setAttribute("getFormat", String.valueOf(StatementGenerator.defaultGetFormat));
        return element;
    }

    @Override
    public void loadState(Element state) {
        this.setSetFormat(state.getAttributeValue("setFormat"));
        this.setGetFormat(state.getAttributeValue("getFormat"));
    }

    public String getSetFormat() {
        return setFormat;
    }

    public void setSetFormat(String setFormat) {
        this.setFormat = setFormat;
    }

    public String getGetFormat() {
        return getFormat;
    }

    public void setGetFormat(String getFormat) {
        this.getFormat = getFormat;
    }

}
